static cmVS7FlagTable cmVS12RCFlagTable[] = {
  // Bool Properties
  { "NullTerminateStrings", "n", "", "true", 0 },

  { 0, 0, 0, 0, 0 }
};
